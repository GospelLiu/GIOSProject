//
//  WebVideoTest.h
//  GIOSProjectDemo
//
//  Created by liufuyin on 16/9/2.
//  Copyright © 2016年 liufuyin. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface WebVideoTest : UIViewController

@end
